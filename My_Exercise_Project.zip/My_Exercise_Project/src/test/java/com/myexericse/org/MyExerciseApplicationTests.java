package com.myexericse.org;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
