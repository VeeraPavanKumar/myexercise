package com.myexercise.org.utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.myexericse.org.Exception.MyExerciseException;

@Aspect
@Component
public class MyExerciseLoggingAspect {
	public static final Log LOGGER=LogFactory.getLog(MyExerciseLoggingAspect.class);
	
	
	@AfterThrowing(pointcut = "execution(* com.myexecise.org.service.*Impl.*(..))",throwing = "exception")
	public void logServiceException(MyExerciseException exception) {
		LOGGER.error(exception.getMessage(),exception);
	}

}
