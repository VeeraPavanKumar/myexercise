package com.myexericse.org.entity.client;

public enum ClientStatus {
ACTIVE, INACTIVE
}
