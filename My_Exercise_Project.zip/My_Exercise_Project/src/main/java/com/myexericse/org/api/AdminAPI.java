package com.myexericse.org.api;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.clientdto.ClientDTO;
import com.myexericse.org.entity.client.ClientStatus;
import com.myexericse.org.entity.trainer.TrainerStatus;
import com.myexericse.org.service.admin.AdminInt;
import com.myexericse.org.trainerdto.TrainerDTO;

@CrossOrigin
@Validated
@RestController
//@RequestMapping(value = "adminapi")
public class AdminAPI {

	@Autowired
	private AdminInt adminService;
	@Autowired
	private Environment environment;

	@GetMapping(value = "view-client/{status}")
	public ResponseEntity<List<ClientDTO>> viewRegisteredClients(
			@PathVariable @NotNull(message = "{invalid.status.search}") ClientStatus status) throws MyExerciseException {
		return new ResponseEntity<List<ClientDTO>>(adminService.viewAllRegisteredClients(status),
				HttpStatus.OK);
	}
	@GetMapping(value = "view-all-clients/")
	public ResponseEntity<List<ClientDTO>> viewClients(
			) throws MyExerciseException {
		return new ResponseEntity<List<ClientDTO>>(adminService.viewAllClients(),
				HttpStatus.OK);
	}
	@GetMapping(value = "view-Client/{ClientId}")
	public ResponseEntity<ClientDTO> viewRegisteredClient(
			@PathVariable @NotNull(message = "{invalid.status.search}") Integer clientId) throws MyExerciseException {
		return new ResponseEntity<ClientDTO>(adminService.viewRegisteredClient(clientId), HttpStatus.OK);
	}


	/*
	 * @PutMapping(value = "Clients/Status/{ClientId}") public ResponseEntity<?>
	 * inActiveClient(@PathVariable Integer ClientId) throws MyExerciseException {
	 * adminService.inActiveClientStatus(ClientId);
	 * 
	 * return new ResponseEntity<>(environment.getProperty("AdminAPI.APPROVED"),
	 * HttpStatus.OK); }
	 */


	@PutMapping(value = "Clients/Status/{ClientId}")
	public ResponseEntity<?> rejectClient(@PathVariable Integer clientId) throws MyExerciseException {
		adminService.inActiveClientStatus(clientId);

		return new ResponseEntity<>(environment.getProperty("AdminAPI.Client.INACTIVE"), HttpStatus.OK);
	}
//Trainer//
	@GetMapping(value = "view-trainer/{status}")
	public ResponseEntity<List<TrainerDTO>> viewRegisteredTrainers(
			@PathVariable @NotNull(message = "{invalid.status.search}") TrainerStatus status) throws MyExerciseException {
		return new ResponseEntity<List<TrainerDTO>>(adminService.viewAllRegisteredTrainers(status),
				HttpStatus.OK);
	}
	@GetMapping(value = "view-all-trainers/")
	public ResponseEntity<List<TrainerDTO>> viewTrainers(
			) throws MyExerciseException {
		return new ResponseEntity<List<TrainerDTO>>(adminService.viewAllTrainers(),
				HttpStatus.OK);
	}
	@GetMapping(value = "view-Trainer/{TrainerId}")
	public ResponseEntity<TrainerDTO> viewRegisteredTrainer(
			@PathVariable @NotNull(message = "{invalid.status.search}") Integer trainerId) throws MyExerciseException {
		return new ResponseEntity<TrainerDTO>(adminService.viewRegisteredTrainer(trainerId), HttpStatus.OK);
	}


	/*
	 * @PutMapping(value = "Clients/Status/{ClientId}") public ResponseEntity<?>
	 * inActiveClient(@PathVariable Integer ClientId) throws MyExerciseException {
	 * adminService.inActiveClientStatus(ClientId);
	 * 
	 * return new ResponseEntity<>(environment.getProperty("AdminAPI.APPROVED"),
	 * HttpStatus.OK); }
	 */


	@PutMapping(value = "Trainers/Status/{TrainerId}")
	public ResponseEntity<?> rejectTrainer(@PathVariable Integer trainerId) throws MyExerciseException {
		adminService.inActiveClientStatus(trainerId);

		return new ResponseEntity<>(environment.getProperty("AdminAPI.Trainer.INACTIVE"), HttpStatus.OK);
	}
}