package com.myexericse.org.repository.trainerrepo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.myexericse.org.entity.trainer.TrainerRegistration;
import com.myexericse.org.entity.trainer.TrainerStatus;
@Repository(value = "trainerRepository")
public interface TrainerRepository extends CrudRepository<TrainerRegistration, Integer>{
	TrainerRegistration findByEmail(String email);

	TrainerRegistration findByContact(String contactNumber);

	List<TrainerRegistration> findByStatus(TrainerStatus status);
}
