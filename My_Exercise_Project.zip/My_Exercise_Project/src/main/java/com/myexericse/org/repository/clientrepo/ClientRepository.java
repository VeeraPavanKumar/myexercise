package com.myexericse.org.repository.clientrepo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.myexericse.org.entity.client.ClientRegistration;
import com.myexericse.org.entity.client.ClientStatus;
@Repository(value = "clientRepository")
public interface ClientRepository extends CrudRepository<ClientRegistration, Integer>{
	ClientRegistration findByEmail(String email);

	ClientRegistration findByContact(String contactNumber);

	List<ClientRegistration> findByStatus(ClientStatus status);
}
