package com.myexericse.org.service.trainerservice;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.trainerdto.TrainerDTO;

public interface TrainerInt {
	public String validLogin(UserLoginDTO dto) throws MyExerciseException;

	public TrainerDTO trainerRegistration(TrainerDTO trainerDTO) throws MyExerciseException;

	TrainerDTO trainerValidLogin(UserLoginDTO dto) throws MyExerciseException;

	TrainerDTO updateDetails(UpdateDetailsDTO dto,Integer trainerId) throws MyExerciseException;
}
