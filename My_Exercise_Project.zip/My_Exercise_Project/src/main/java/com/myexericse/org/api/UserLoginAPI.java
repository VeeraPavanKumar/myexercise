package com.myexericse.org.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.service.clientservice.ClientInt;
import com.myexericse.org.service.trainerservice.TrainerInt;


@RestController
//@RequestMapping(value = "login-api")
public class UserLoginAPI {

	@Autowired
	private ClientInt clientLoginService;
	@Autowired
	private TrainerInt trainerLoginService;


	@PostMapping(value = "/user/login")
	public ResponseEntity<String> clientValidLogin(@RequestBody UserLoginDTO loginDTO) throws MyExerciseException {
	
		String b = clientLoginService.validLogin(loginDTO);
		return new ResponseEntity<>(b, HttpStatus.OK);
	}
	@PostMapping(value = "/trainer/login")
	public ResponseEntity<String> trainerValidLogin(@RequestBody UserLoginDTO loginDTO) throws MyExerciseException {
	
		String b = trainerLoginService.validLogin(loginDTO);
		return new ResponseEntity<>(b, HttpStatus.OK);
	}
}