package com.myexericse.org.repository.userloginrepo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.myexericse.org.entity.UserLogin;


@Repository(value = "userLoginRepository")
public interface UserLoginRepository extends CrudRepository<UserLogin, Integer> {
	// select * from user_login where user_name="";QueryApproach
	// @Query(select * from user_login where user_name="";)
	// findDetilsBasedOnUserName();
	UserLogin findByUserName(String userName);

	List<UserLogin> findByUserRole(String userRole);

	UserLogin findByEmail(String email);

	UserLogin findByContact(String contact);
}
