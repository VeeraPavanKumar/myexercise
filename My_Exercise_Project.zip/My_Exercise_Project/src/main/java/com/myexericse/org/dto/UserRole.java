package com.myexericse.org.dto;

public enum UserRole {
	ADMIN, SUPPORT, TRAINER,CLIENT
}
