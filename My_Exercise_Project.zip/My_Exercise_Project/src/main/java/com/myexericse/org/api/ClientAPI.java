package com.myexericse.org.api;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.dto.clientdto.ClientDTO;
import com.myexericse.org.service.clientservice.ClientInt;


@CrossOrigin
@RestController
@RequestMapping(value = "Client-api")
public class ClientAPI {
	static int i = 0;
	static int j = 0;
	@Autowired
	private ClientInt clientService;

	
	@PostMapping(value = "signup")
	public ResponseEntity<ClientDTO> registerClient(@RequestBody @Valid ClientDTO clientDTO)
			throws MyExerciseException {

		ResponseEntity <ClientDTO> resCLI=new ResponseEntity<ClientDTO>(clientService.clientRegistration(clientDTO),
				HttpStatus.CREATED);
		return resCLI;
		
	}

	@PostMapping(value = "signin")
	public ResponseEntity<ClientDTO> validLogin(@RequestBody UserLoginDTO dto) throws MyExerciseException {

		return new ResponseEntity<ClientDTO>(clientService.clientValidLogin(dto), HttpStatus.OK);
	}

	@PutMapping(value = "/update/{ClientId}")
	public ResponseEntity<ClientDTO> updatePersonalDetails(@RequestBody UpdateDetailsDTO dto,
			@PathVariable Integer ClientId) throws MyExerciseException {

		return new ResponseEntity<ClientDTO>(clientService.updateDetails(dto, ClientId), HttpStatus.OK);
	}



}
