package com.myexericse.org.service.clientservice;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.dto.clientdto.ClientDTO;

public interface ClientInt {
	public String validLogin(UserLoginDTO dto) throws MyExerciseException;

	public ClientDTO clientRegistration(ClientDTO clientDTO) throws MyExerciseException;

	ClientDTO clientValidLogin(UserLoginDTO dto) throws MyExerciseException;

	ClientDTO updateDetails(UpdateDetailsDTO dto,Integer clientId) throws MyExerciseException;
}