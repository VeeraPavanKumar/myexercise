package com.myexericse.org.dto.clientdto;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.myexericse.org.entity.client.ClientAddress;
import com.myexericse.org.entity.client.ClientRegistration;
import com.myexericse.org.entity.client.ClientStatus;



public class ClientDTO {

	private Integer clientId;
	@NotNull(message = "{seller.fname.empty}")
	@Pattern(regexp = "([A-Z][a-z]+)([ ][A-Z][a-z]+)*", message = "{seller.fname.invalid}")
	private String firstName;
	@NotNull(message = "{seller.lname.empty}")
	@Pattern(regexp = "([A-Z][a-z]+)([ ][A-Z][a-z]+)*", message = "{seller.lname.invalid}")
	private String lastName;
	@Email(message = "{seller.email.invalid}")
	@NotNull(message = "{seller.email.empty}")
	private String email;
	@NotNull(message = "{seller.contact.null}")
	private String contact;
	@NotNull(message = "{seller.password.null}")
	private String password;


	@Valid
	private ClientAddressDTO address;
	private ClientStatus status;

	public ClientStatus getStatus() {
		return status;
	}

	public void setStatus(ClientStatus status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ClientAddressDTO getAddress() {
		return address;
	}

	public void setAddress(ClientAddressDTO address) {
		this.address = address;
	}

	public Integer getClientId() {
		return clientId;
	}

	public void SetClientId(Integer clientId) {
		this.clientId = clientId;
	}

	public static ClientDTO entityToDTO(ClientRegistration p) {
		ClientDTO dto = new ClientDTO();
		dto.SetClientId(p.getClientId());
		dto.setFirstName(p.getFirstName());
		dto.setLastName(p.getLastName());
		dto.setContact(p.getContact());
		dto.setEmail(p.getEmail());
		dto.setStatus(p.getStatus());
		ClientAddressDTO aDTO = new ClientAddressDTO();
		ClientAddress a = p.getAddress();
		aDTO.setAddressLine1(a.getAddressLine1());
		aDTO.setAddressLine2(a.getAddressLine2());
		aDTO.setCity(a.getCity());
		aDTO.setPincode(a.getPincode());
		aDTO.setState(a.getState());
		dto.setAddress(aDTO);
		return dto;

	}

	public static ClientRegistration dtoToEntity(ClientDTO clientDTO) {

		ClientRegistration newSR = new ClientRegistration();
		newSR.setContact(clientDTO.getContact());
		newSR.setEmail(clientDTO.getEmail());
		newSR.setFirstName(clientDTO.getFirstName());
		newSR.setLastName(clientDTO.getLastName());
		newSR.setStatus(ClientStatus.INACTIVE);
		newSR.setPassword(clientDTO.getPassword());
		ClientAddress address = new ClientAddress();
		ClientAddressDTO adto = clientDTO.getAddress();
		address.setAddressLine1(adto.getAddressLine1());
		address.setAddressLine2(adto.getAddressLine2());
		address.setCity(adto.getCity());
		address.setState(adto.getState());
		address.setPincode(adto.getPincode());
		newSR.setAddress(address);
		return newSR;
	}

}
