package com.myexericse.org.service.trainerservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.entity.UserLogin;
import com.myexericse.org.entity.trainer.TrainerRegistration;
import com.myexericse.org.repository.trainerrepo.TrainerRepository;
import com.myexericse.org.repository.userloginrepo.UserLoginRepository;
import com.myexericse.org.trainerdto.TrainerDTO;
@Service(value = "trainerService")

public class TrainerServiceImpl implements TrainerInt {
	@Autowired
	public UserLoginRepository userLoginRepository;
	@Autowired
	private TrainerRepository trainerRepository;
	@Autowired
	private Environment environment;

	private String validation(String variable, String password, UserLogin ulogin) throws MyExerciseException {
		if (ulogin == null)
			throw new MyExerciseException(environment.getProperty("TrainerService.USER_NOT_FOUND"));

		if (variable.equals(ulogin.getEmail()) && password.equals(ulogin.getPassword())) {
			return "TrainerService.Login_STATUS";
		} else
			throw new MyExerciseException(environment.getProperty("TrainerService.Invalid_Login"));
	}

	@Override
	public String validLogin(UserLoginDTO dto) throws MyExerciseException {
		UserLogin ulogin = null;
		if (dto.getUser_name() != null) {
			ulogin = userLoginRepository.findByUserName(dto.getUser_name());
			return validation(dto.getUser_name(), dto.getPassword(), ulogin);
		} else if (dto.getContact() != null) {
			ulogin = userLoginRepository.findByContact(dto.getContact());
			return validation(dto.getContact(), dto.getPassword(), ulogin);

		} else if (dto.getEmail() != null)
			ulogin = userLoginRepository.findByEmail(dto.getEmail());
		return validation(dto.getEmail(), dto.getPassword(), ulogin);

	}


	@Override
	public TrainerDTO trainerRegistration(TrainerDTO trainerDTO) throws MyExerciseException {

		TrainerRegistration sr = trainerRepository.findByContact(trainerDTO.getContact());
		if (sr != null)
			throw new MyExerciseException(environment.getProperty("TrainerService.Phone_Exists"));
		TrainerRegistration sr2 = trainerRepository.findByEmail(trainerDTO.getEmail());
		if (sr2 != null)
			throw new MyExerciseException(environment.getProperty("TrainerService.Email_Exists"));
		TrainerRegistration newSR = TrainerDTO.dtoToEntity(trainerDTO);

		Integer i = trainerRepository.save(newSR).getTrainerId();
		trainerDTO.SetTrainerId(i);
		UserLogin u = new UserLogin();
		u.setPassword(trainerDTO.getPassword());
		String s[] = trainerDTO.getEmail().split("@");
		String username = s[0] + trainerDTO.getContact().substring(2, 6);
		u.setUserName(username);

		u.setContact(trainerDTO.getContact());
		u.setEmail(trainerDTO.getEmail());
		userLoginRepository.save(u);
		return trainerDTO;
	}

	@Override
	public TrainerDTO trainerValidLogin(UserLoginDTO dto) throws MyExerciseException {

		TrainerRegistration s = trainerRepository.findByContact(dto.getContact());
		if (s == null)
			throw new MyExerciseException("TrainerService.Trainer_NOT_REGISTERED");
		if (!dto.getContact().equals(s.getContact()) && dto.getPassword().equals(s.getPassword()))
			throw new MyExerciseException("TrainerService.INVALID_CREDENTIALS");
		return TrainerDTO.entityToDTO(s);
	}

	@Override
	public TrainerDTO updateDetails(UpdateDetailsDTO dto, Integer trainerId) throws MyExerciseException {

		Optional<TrainerRegistration> opt = trainerRepository.findById(trainerId);
		TrainerRegistration sr = opt.orElseThrow(() -> new MyExerciseException("TrainerService.Trainer_NOT_FOUND"));
		
		TrainerRegistration sr1 = trainerRepository.findByContact(dto.getContact());
	
		TrainerRegistration sr2 = trainerRepository.findByEmail(dto.getEmail());
	
		if (sr2 == null) {
			sr.setEmail(dto.getEmail());
		} else {
			if (!sr2.equals(sr)) {

				throw new MyExerciseException(environment.getProperty("TrainerService.Email_Exists"));
			} else
				sr.setEmail(dto.getEmail());

		}
		if (sr1 == null) {
			sr.setContact(dto.getContact());
		} else {
			if (!sr1.equals(sr)) {

				throw new MyExerciseException(environment.getProperty("TrainerService.Phone_Exists"));
			} else
				sr.setContact(dto.getContact());

		}
		sr.setFirstName(dto.getFirstName());
		sr.setLastName(dto.getLastName());

		trainerRepository.save(sr);
		System.out.println("check6");
		return TrainerDTO.entityToDTO(sr);
	}

}
