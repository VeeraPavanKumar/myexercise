package com.myexericse.org.trainerdto;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.myexericse.org.entity.trainer.TrainerAddress;
import com.myexericse.org.entity.trainer.TrainerRegistration;
import com.myexericse.org.entity.trainer.TrainerStatus;



public class TrainerDTO {

	private Integer trainerId;
	@NotNull(message = "{seller.fname.empty}")
	@Pattern(regexp = "([A-Z][a-z]+)([ ][A-Z][a-z]+)*", message = "{seller.fname.invalid}")
	private String firstName;
	@NotNull(message = "{seller.lname.empty}")
	@Pattern(regexp = "([A-Z][a-z]+)([ ][A-Z][a-z]+)*", message = "{seller.lname.invalid}")
	private String lastName;
	@Email(message = "{seller.email.invalid}")
	@NotNull(message = "{seller.email.empty}")
	private String email;
	@NotNull(message = "{seller.contact.null}")
	private String contact;
	@NotNull(message = "{seller.password.null}")
	private String password;


	@Valid
	private TrainerAddressDTO address;
	private TrainerStatus status;

	public TrainerStatus getStatus() {
		return status;
	}

	public void setStatus(TrainerStatus status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public TrainerAddressDTO getAddress() {
		return address;
	}

	public void setAddress(TrainerAddressDTO address) {
		this.address = address;
	}

	public Integer getTrainerId() {
		return trainerId;
	}

	public void SetTrainerId(Integer trainerId) {
		this.trainerId = trainerId;
	}

	public static TrainerDTO entityToDTO(TrainerRegistration p) {
		TrainerDTO dto = new TrainerDTO();
		dto.SetTrainerId(p.getTrainerId());
		dto.setFirstName(p.getFirstName());
		dto.setLastName(p.getLastName());
		dto.setContact(p.getContact());
		dto.setEmail(p.getEmail());
		dto.setStatus(p.getStatus());
		TrainerAddressDTO aDTO = new TrainerAddressDTO();
		TrainerAddress a = p.getAddress();
		aDTO.setAddressLine1(a.getAddressLine1());
		aDTO.setAddressLine2(a.getAddressLine2());
		aDTO.setCity(a.getCity());
		aDTO.setPincode(a.getPincode());
		aDTO.setState(a.getState());
		dto.setAddress(aDTO);
		return dto;

	}

	public static TrainerRegistration dtoToEntity(TrainerDTO trainerDTO) {

		TrainerRegistration newSR = new TrainerRegistration();
		newSR.setContact(trainerDTO.getContact());
		newSR.setEmail(trainerDTO.getEmail());
		newSR.setFirstName(trainerDTO.getFirstName());
		newSR.setLastName(trainerDTO.getLastName());
		newSR.setStatus(TrainerStatus.Inactive);
		newSR.setPassword(trainerDTO.getPassword());
		TrainerAddress address = new TrainerAddress();
		TrainerAddressDTO adto = trainerDTO.getAddress();
		address.setAddressLine1(adto.getAddressLine1());
		address.setAddressLine2(adto.getAddressLine2());
		address.setCity(adto.getCity());
		address.setState(adto.getState());
		address.setPincode(adto.getPincode());
		newSR.setAddress(address);
		return newSR;
	}

}
