package com.myexericse.org.entity.trainer;

public enum TrainerStatus {
	Active,Inactive

}
