package com.myexericse.org.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.service.trainerservice.TrainerInt;
import com.myexericse.org.trainerdto.TrainerDTO;


@CrossOrigin
@RestController
//@RequestMapping(value = "Trainer-api")
public class TrainerAPI {
	static int i = 0;
	static int j = 0;
	@Autowired
	private TrainerInt trainerService;

	@PostMapping(value = "register")
	public ResponseEntity<TrainerDTO> registerTrainer(@RequestBody @Valid TrainerDTO trainerDTO)
			throws MyExerciseException {

		return new ResponseEntity<TrainerDTO>(trainerService.trainerRegistration(trainerDTO),
				HttpStatus.CREATED);
	}

	@PostMapping(value = "login")
	public ResponseEntity<TrainerDTO> validLogin(@RequestBody UserLoginDTO dto) throws MyExerciseException {

		return new ResponseEntity<TrainerDTO>(trainerService.trainerValidLogin(dto), HttpStatus.OK);
	}

	@PutMapping(value = "/update/{TrainerId}")
	public ResponseEntity<TrainerDTO> updatePersonalDetails(@RequestBody UpdateDetailsDTO dto,
			@PathVariable Integer TrainerId) throws MyExerciseException {

		return new ResponseEntity<TrainerDTO>(trainerService.updateDetails(dto, TrainerId), HttpStatus.OK);
	}
}
