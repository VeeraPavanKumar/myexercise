package com.myexericse.org.service.admin;

import java.util.List;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.clientdto.ClientDTO;
import com.myexericse.org.entity.client.ClientStatus;
import com.myexericse.org.entity.trainer.TrainerStatus;
import com.myexericse.org.trainerdto.TrainerDTO;


public interface AdminInt {
	public List<ClientDTO> viewAllRegisteredClients(ClientStatus status) throws MyExerciseException;

	public ClientDTO viewRegisteredClient(Integer client_id) throws MyExerciseException;

	

	
	public void inActiveClientStatus(Integer client_id) throws MyExerciseException;

	

	public List<ClientDTO> viewAllClients() throws MyExerciseException;
	
	public List<TrainerDTO> viewAllRegisteredTrainers(TrainerStatus status) throws MyExerciseException;

	public TrainerDTO viewRegisteredTrainer(Integer trainer_id) throws MyExerciseException;

	

	
	public void inActiveTrainerStatus(Integer trainer_id) throws MyExerciseException;

	

	public List<TrainerDTO> viewAllTrainers() throws MyExerciseException;
}
