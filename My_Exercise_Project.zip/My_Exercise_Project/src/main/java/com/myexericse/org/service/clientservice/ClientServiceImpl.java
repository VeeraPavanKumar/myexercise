package com.myexericse.org.service.clientservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.UpdateDetailsDTO;
import com.myexericse.org.dto.UserLoginDTO;
import com.myexericse.org.dto.clientdto.ClientDTO;
import com.myexericse.org.entity.UserLogin;
import com.myexericse.org.entity.client.ClientRegistration;
import com.myexericse.org.repository.clientrepo.ClientRepository;
import com.myexericse.org.repository.userloginrepo.UserLoginRepository;
@Service(value = "clientService")
public class ClientServiceImpl implements ClientInt {
	@Autowired
	public UserLoginRepository userLoginRepository;
	@Autowired
	private ClientRepository clientRepository;
	@Autowired
	private Environment environment;

	private String validation(String variable, String password, UserLogin ulogin) throws MyExerciseException {
		if (ulogin == null)
			throw new MyExerciseException(environment.getProperty("ClientService.USER_NOT_FOUND"));

		if (variable.equals(ulogin.getEmail()) && password.equals(ulogin.getPassword())) {
			return "ClientService.Login_STATUS";
		} else
			throw new MyExerciseException(environment.getProperty("ClientService.Invalid_Login"));
	}

	@Override
	public String validLogin(UserLoginDTO dto) throws MyExerciseException {
		UserLogin ulogin = null;
		if (dto.getUser_name() != null) {
			ulogin = userLoginRepository.findByUserName(dto.getUser_name());
			return validation(dto.getUser_name(), dto.getPassword(), ulogin);
		} else if (dto.getContact() != null) {
			ulogin = userLoginRepository.findByContact(dto.getContact());
			return validation(dto.getContact(), dto.getPassword(), ulogin);

		} else if (dto.getEmail() != null)
			ulogin = userLoginRepository.findByEmail(dto.getEmail());
		return validation(dto.getEmail(), dto.getPassword(), ulogin);

	}


	@Override
	public ClientDTO clientRegistration(ClientDTO clientDTO) throws MyExerciseException {

		ClientRegistration sr = clientRepository.findByContact(clientDTO.getContact());
		if (sr != null)
			throw new MyExerciseException(environment.getProperty("ClientService.Phone_Exists"));
		ClientRegistration sr2 = clientRepository.findByEmail(clientDTO.getEmail());
		if (sr2 != null)
			throw new MyExerciseException(environment.getProperty("ClientService.Email_Exists"));
		ClientRegistration newSR = ClientDTO.dtoToEntity(clientDTO);

		Integer i = clientRepository.save(newSR).getClientId();
		clientDTO.SetClientId(i);
		UserLogin u = new UserLogin();
		u.setPassword(clientDTO.getPassword());
		String s[] = clientDTO.getEmail().split("@");
		String username = s[0] + clientDTO.getContact().substring(2, 6);
		u.setUserName(username);

		u.setContact(clientDTO.getContact());
		u.setEmail(clientDTO.getEmail());
		userLoginRepository.save(u);
		return clientDTO;
	}

	@Override
	public ClientDTO clientValidLogin(UserLoginDTO dto) throws MyExerciseException {

		ClientRegistration s = clientRepository.findByContact(dto.getContact());
		if (s == null)
			throw new MyExerciseException("ClientService.Client_NOT_REGISTERED");
		if (!dto.getContact().equals(s.getContact()) && dto.getPassword().equals(s.getPassword()))
			throw new MyExerciseException("ClientService.INVALID_CREDENTIALS");
		return ClientDTO.entityToDTO(s);
	}

	@Override
	public ClientDTO updateDetails(UpdateDetailsDTO dto, Integer clientId) throws MyExerciseException {

		Optional<ClientRegistration> opt = clientRepository.findById(clientId);
		ClientRegistration sr = opt.orElseThrow(() -> new MyExerciseException("ClientService.Client_NOT_FOUND"));
		
		ClientRegistration sr1 = clientRepository.findByContact(dto.getContact());
	
		ClientRegistration sr2 = clientRepository.findByEmail(dto.getEmail());
	
		if (sr2 == null) {
			sr.setEmail(dto.getEmail());
		} else {
			if (!sr2.equals(sr)) {

				throw new MyExerciseException(environment.getProperty("ClientService.Email_Exists"));
			} else
				sr.setEmail(dto.getEmail());

		}
		if (sr1 == null) {
			sr.setContact(dto.getContact());
		} else {
			if (!sr1.equals(sr)) {

				throw new MyExerciseException(environment.getProperty("ClientService.Phone_Exists"));
			} else
				sr.setContact(dto.getContact());

		}
		sr.setFirstName(dto.getFirstName());
		sr.setLastName(dto.getLastName());

		clientRepository.save(sr);
		System.out.println("check6");
		return ClientDTO.entityToDTO(sr);
	}

}


