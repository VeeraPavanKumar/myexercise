package com.myexericse.org.Exception;

public class MyExerciseException extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public MyExerciseException(String message) {
	super(message);
}
}
