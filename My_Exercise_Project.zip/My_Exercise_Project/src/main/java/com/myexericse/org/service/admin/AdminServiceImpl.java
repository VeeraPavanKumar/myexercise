package com.myexericse.org.service.admin;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.myexericse.org.Exception.MyExerciseException;
import com.myexericse.org.dto.clientdto.ClientDTO;
import com.myexericse.org.entity.client.ClientRegistration;
import com.myexericse.org.entity.client.ClientStatus;
import com.myexericse.org.entity.trainer.TrainerRegistration;
import com.myexericse.org.entity.trainer.TrainerStatus;
import com.myexericse.org.repository.clientrepo.ClientRepository;
import com.myexericse.org.repository.trainerrepo.TrainerRepository;
import com.myexericse.org.trainerdto.TrainerDTO;
@Service(value = "adminService")
public class AdminServiceImpl implements AdminInt{
	@Autowired
	private ClientRepository clientRepository;
	@Autowired
	private TrainerRepository trainerRepository;
	@Autowired
	private Environment environment;
	@Override
	public List<ClientDTO> viewAllRegisteredClients(ClientStatus status) throws MyExerciseException {
		List<ClientRegistration> list = clientRepository.findByStatus(status);
		return list.stream().map(p -> {
			ClientDTO dto = ClientDTO.entityToDTO(p);
			return dto;
		}).collect(Collectors.toList());
	}

	@Override
	public ClientDTO viewRegisteredClient(Integer client_id) throws MyExerciseException {
		Optional<ClientRegistration> op = clientRepository.findById(client_id);
		ClientRegistration sr = op
				.orElseThrow(() -> new MyExerciseException(environment.getProperty("AdminService.ClientNotRegistered")));
		return ClientDTO.entityToDTO(sr);


	}

	@Override
	public void inActiveClientStatus(Integer client_id) throws MyExerciseException {
		Optional<ClientRegistration> op = clientRepository.findById(client_id);
		ClientRegistration sr = op
				.orElseThrow(() -> new MyExerciseException(environment.getProperty("AdminService.ClientNotRegistered")));
		sr.setStatus(ClientStatus.INACTIVE);
		clientRepository.save(sr);
	}

	@Override
	public List<ClientDTO> viewAllClients() throws MyExerciseException {
		Iterable<ClientRegistration> i = clientRepository.findAll();
		List<ClientDTO> dto = new ArrayList<ClientDTO>();

		i.forEach(t -> {
			
			dto.add(ClientDTO.entityToDTO(t));
		});
		if (!dto.isEmpty())
			return dto;
		else
			throw new MyExerciseException("AdminService.NO_CLIENTS_FOUND");

	}

	@Override
	public List<TrainerDTO> viewAllRegisteredTrainers(TrainerStatus status) throws MyExerciseException {
		List<TrainerRegistration> list = trainerRepository.findByStatus(status);
		return list.stream().map(p -> {
			TrainerDTO dto = TrainerDTO.entityToDTO(p);
			return dto;
		}).collect(Collectors.toList());
	}

	@Override
	public TrainerDTO viewRegisteredTrainer(Integer trainer_id) throws MyExerciseException {
		Optional<TrainerRegistration> op = trainerRepository.findById(trainer_id);
		TrainerRegistration sr = op
				.orElseThrow(() -> new MyExerciseException(environment.getProperty("AdminService.TrainerNotRegistered")));
		return TrainerDTO.entityToDTO(sr);

	}

	@Override
	public void inActiveTrainerStatus(Integer trainer_id) throws MyExerciseException {
		Optional<TrainerRegistration> op = trainerRepository.findById(trainer_id);
		TrainerRegistration sr = op
				.orElseThrow(() -> new MyExerciseException(environment.getProperty("AdminService.TrainerNotRegistered")));
		sr.setStatus(TrainerStatus.Inactive);
		trainerRepository.save(sr);
		
	}

	@Override
	public List<TrainerDTO> viewAllTrainers() throws MyExerciseException {
		Iterable<TrainerRegistration> i = trainerRepository.findAll();
		List<TrainerDTO> dto = new ArrayList<TrainerDTO>();

		i.forEach(t -> {
			
			dto.add(TrainerDTO.entityToDTO(t));
		});
		if (!dto.isEmpty())
			return dto;
		else
			throw new MyExerciseException("AdminService.NO_TRAINERS_FOUND");
	}

}
