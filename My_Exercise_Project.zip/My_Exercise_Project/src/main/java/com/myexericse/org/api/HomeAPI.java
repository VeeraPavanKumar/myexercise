package com.myexericse.org.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HomeAPI {
	@RequestMapping("/")
	public ModelAndView index ( ) {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.setViewName("exercise");
	    return modelAndView;
	}
}
