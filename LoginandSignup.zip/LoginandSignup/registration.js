    // Function to show/hide the password in the sign-in modal
    function togglePasswordVisibility() {
        const passwordInput = document.querySelector('#signinModal .password');
        const showHideIcon = document.querySelector('#signinModal .showHidePw');

        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            showHideIcon.classList.remove('fa-eye-slash');
            showHideIcon.classList.add('fa-eye');
        } else {
            passwordInput.type = 'password';
            showHideIcon.classList.remove('fa-eye');
            showHideIcon.classList.add('fa-eye-slash');
        }
    }

// Function to hide the sign-in modal
function hideSignInModal() {
    const signinModal = document.getElementById('signinModal');
    signinModal.style.display = 'none';
}

// Function to show the sign-up modal
function showSignUpModal() {
    const signupModal = document.getElementById('signupModal');
    signupModal.style.display = 'block';
}

// Function to hide the sign-up modal
function hideSignUpModal() {
    const signupModal = document.getElementById('signupModal');
    signupModal.style.display = 'none';
}

// Function to show the sign-in modal and hide the sign-up modal
function showSignInModal() {
    hideSignUpModal(); // Hide the sign-up modal first
    const signinModal = document.getElementById('signinModal');
    signinModal.style.display = 'block';
}

// Close the modal when clicking outside the modal content
window.onclick = function (event) {
    const modals = document.getElementsByClassName('modal');
    for (const modal of modals) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }
};


