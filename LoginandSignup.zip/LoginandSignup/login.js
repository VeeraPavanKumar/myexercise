const container = document.querySelector(".container");
const pwShowHide = document.querySelectorAll(".showHidePw");
const pwFields = document.querySelectorAll(".password");
const signUp = document.querySelector(".signup-link");
const login = document.querySelector(".login-link");

// Function to show/hide password and change icon
pwShowHide.forEach(eyeIcon => {
  eyeIcon.addEventListener("click", () => {
    pwFields.forEach(pwField => {
      if (pwField.type === "password") {
        pwField.type = "text";
      } else {
        pwField.type = "password";
      }
    });

    // Toggle eye icons
    pwShowHide.forEach(icon => {
      icon.classList.toggle("uil-eye");
      icon.classList.toggle("uil-eye-slash");
    });
  });
});

  

    // Function to show the sign-in modal
    function showSignInModal() {
        const signinModal = document.getElementById('signinModal');
        signinModal.style.display = 'block';
    }

    // Function to show the sign-up modal
    function showSignUpModal() {
        const signupModal = document.getElementById('signupModal');
        signupModal.style.display = 'block';
    }





// Function to switch between signup and login forms
signUp.addEventListener("click", () => {
  container.classList.add("active");
});

login.addEventListener("click", () => {
  container.classList.remove("active");
});
